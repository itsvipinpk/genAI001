const searchInput = document.querySelector("#search-input");
const reviewDialog = document.querySelector("#review-dialog");
const storyForm = document.querySelector("#story-form");
const storyInput = document.querySelector("#story-input");
const dialogFeedback = document.querySelector("#dialog-feedback");
const analyzerForm = document.querySelector("#analyzer-form");
const jiraKeyInput = document.querySelector("#jira-key");
const jiraKeyField = document.querySelector(".jira-key-field");
const reviewButton = document.querySelector("#review-story-button");
const reviewButtonLabel = reviewButton.querySelector(".analyzer-submit-label");
const workspace = document.querySelector(".workspace-card");
const workspaceStateLabel = document.querySelector("#workspace-state-label");
const workspaceWaiting = document.querySelector("#workspace-waiting");
const workspaceLoading = document.querySelector("#workspace-loading");
const workspaceError = document.querySelector("#workspace-error");
const workspaceFeedback = document.querySelector("#workspace-feedback");
const workspaceErrorKicker = document.querySelector("#workspace-error-kicker");
const workspaceErrorTitle = document.querySelector("#workspace-error-title");
const workspaceErrorMessage = document.querySelector("#workspace-error-message");
const workspaceResult = document.querySelector("#workspace-result");
const workspaceResultContent = document.querySelector("#workspace-result-content");
const resultStoryKey = document.querySelector("#result-story-key");
const analysisCompleteBadge = document.querySelector("#analysis-complete-badge");
const loadingStatus = document.querySelector("#loading-status");
const loadingStep = document.querySelector("#loading-step");
const loadingKey = document.querySelector("#loading-key");
const progressFill = document.querySelector("#progress-fill");
const analyzerModules = [...analyzerForm.querySelectorAll('input[name="modules"]')];

const reviewEndpoint = "http://localhost:5678/webhook/userstory_reviewer";
const progressMessages = [
  "Reading story key...",
  "Contacting Jira API...",
  "Evaluating description clarity...",
  "Synthesizing recommendations...",
];

let loadingTimer;
let progressTimer;
let requestInProgress = false;

document.querySelector("#new-review-button").addEventListener("click", () => {
  dialogFeedback.hidden = true;
  reviewDialog.showModal();
});

storyForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const story = storyInput.value.trim();
  if (!story) return;

  dialogFeedback.textContent = "Your story is ready for review. Connect Jira to enable AI analysis in your workspace.";
  dialogFeedback.hidden = false;
});

function clearLoadingTimers() {
  if (loadingTimer !== undefined) {
    window.clearTimeout(loadingTimer);
    loadingTimer = undefined;
  }
  if (progressTimer !== undefined) {
    window.clearInterval(progressTimer);
    progressTimer = undefined;
  }
}

function setWorkspaceState(state) {
  clearLoadingTimers();
  workspace.dataset.state = state;
  workspace.setAttribute("aria-busy", String(state === "loading"));
  workspaceWaiting.hidden = state !== "waiting";
  workspaceLoading.hidden = state !== "loading";
  workspaceError.hidden = state !== "error";
  workspaceResult.hidden = state !== "complete";
  workspaceFeedback.hidden = true;
  workspace.classList.remove("is-error");
  workspaceStateLabel.textContent = state === "complete" ? "COMPLETE" : state.toUpperCase();
  analysisCompleteBadge.hidden = state !== "complete";
}

function setFormBusy(isBusy) {
  requestInProgress = isBusy;
  jiraKeyInput.disabled = isBusy;
  reviewButton.disabled = isBusy;
  for (const module of analyzerModules) module.disabled = isBusy;
  reviewButtonLabel.textContent = isBusy ? "Analyzing..." : "Review Story";
  reviewButton.setAttribute("aria-label", isBusy ? "Analyzing story" : "Review Story");
}

function shakeWorkspace() {
  workspace.classList.remove("is-error");
  void workspace.offsetWidth;
  workspace.classList.add("is-error");
}

function showWorkspaceFeedback(message) {
  workspaceFeedback.textContent = message;
  workspaceFeedback.hidden = false;
  shakeWorkspace();
}

function showRequestError(message, title = "We couldn’t reach the review service.") {
  setWorkspaceState("error");
  workspaceErrorKicker.textContent = "CONNECTION FAILURE";
  workspaceErrorTitle.textContent = title;
  workspaceErrorMessage.textContent = message;
  shakeWorkspace();
}

function stringifyResponse(value) {
  if (typeof value === "string") return value.trim();
  if (value === null || value === undefined) return "";
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  return JSON.stringify(value, null, 2);
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, (character) => {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };
    return entities[character];
  });
}

function inlineMarkdown(value) {
  const codeSpans = [];
  let text = escapeHtml(value).replace(/`([^`\n]+)`/g, (_match, code) => {
    const token = `\u0000CODE${codeSpans.length}\u0000`;
    codeSpans.push(`<code>${code}</code>`);
    return token;
  });

  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_match, label, url) =>
    `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`,
  );
  text = text.replace(/\*\*(.+?)\*\*|__(.+?)__/g, (_match, stars, underscores) =>
    `<strong>${stars ?? underscores}</strong>`,
  );
  text = text.replace(/~~(.+?)~~/g, "<del>$1</del>");
  text = text.replace(/(^|[^\w*])\*([^*\n]+)\*(?!\w)/g, "$1<em>$2</em>");
  text = text.replace(/(^|[^\w_])_([^_\n]+)_(?!\w)/g, "$1<em>$2</em>");
  return text.replace(/\u0000CODE(\d+)\u0000/g, (_match, index) => codeSpans[Number(index)]);
}

function isTableDivider(line) {
  const cells = line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|");
  return cells.length > 0 && cells.every((cell) => /^\s*:?-{3,}:?\s*$/.test(cell));
}

function parseTableRow(line) {
  return line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
}

function renderMarkdown(markdown) {
  const lines = markdown.replace(/\r\n?/g, "\n").split("\n");
  const output = [];
  let paragraph = [];
  let listType = "";
  let listItems = [];
  let codeLines = [];
  let codeLanguage = "";
  let insideCode = false;
  let codeFenceCharacter = "";
  let codeFenceLength = 0;

  const flushParagraph = () => {
    if (!paragraph.length) return;
    output.push(`<p>${paragraph.map(inlineMarkdown).join("<br>")}</p>`);
    paragraph = [];
  };
  const flushList = () => {
    if (!listItems.length) return;
    const tag = listType === "ordered" ? "ol" : "ul";
    output.push(`<${tag}>${listItems.map((item) => `<li>${inlineMarkdown(item)}</li>`).join("")}</${tag}>`);
    listItems = [];
    listType = "";
  };
  const flushCode = () => {
    const languageClass = /^[\w+-]+$/.test(codeLanguage) ? ` class="language-${codeLanguage}"` : "";
    output.push(`<pre><code${languageClass}>${escapeHtml(codeLines.join("\n"))}</code></pre>`);
    codeLines = [];
    codeLanguage = "";
  };
  const flushTable = (header, rows) => {
    const headerHtml = header.map((cell) => `<th scope="col">${inlineMarkdown(cell)}</th>`).join("");
    const rowsHtml = rows.map((row) => {
      const cells = header.map((_cell, index) => `<td>${inlineMarkdown(row[index] ?? "")}</td>`).join("");
      return `<tr>${cells}</tr>`;
    }).join("");
    output.push(`<div class="markdown-table-wrap"><table><thead><tr>${headerHtml}</tr></thead><tbody>${rowsHtml}</tbody></table></div>`);
  };

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const fence = line.match(/^\s*(```+|~~~+)\s*([\w+-]*)\s*$/);

    if (insideCode) {
      if (fence && fence[1][0] === codeFenceCharacter && fence[1].length >= codeFenceLength) {
        flushCode();
        insideCode = false;
      } else {
        codeLines.push(line);
      }
      continue;
    }
    if (fence) {
      flushParagraph();
      flushList();
      insideCode = true;
      codeFenceCharacter = fence[1][0];
      codeFenceLength = fence[1].length;
      codeLanguage = fence[2];
      continue;
    }

    const nextLine = lines[index + 1] ?? "";
    if (line.includes("|") && nextLine.includes("|") && isTableDivider(nextLine)) {
      flushParagraph();
      flushList();
      const header = parseTableRow(line);
      const rows = [];
      index += 2;
      while (index < lines.length && lines[index].trim() && lines[index].includes("|")) {
        rows.push(parseTableRow(lines[index]));
        index += 1;
      }
      index -= 1;
      flushTable(header, rows);
      continue;
    }

    const heading = line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
    if (heading) {
      flushParagraph();
      flushList();
      const level = Math.min(heading[1].length, 4);
      output.push(`<h${level}>${inlineMarkdown(heading[2])}</h${level}>`);
      continue;
    }

    if (/^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(line)) {
      flushParagraph();
      flushList();
      output.push("<hr>");
      continue;
    }

    const listMatch = line.match(/^\s*(?:[-+*]\s+|\d+[.)]\s+)(.+)$/);
    if (listMatch) {
      flushParagraph();
      const nextType = /^\s*\d+[.)]\s+/.test(line) ? "ordered" : "unordered";
      if (listType && listType !== nextType) flushList();
      listType = nextType;
      listItems.push(listMatch[1]);
      continue;
    }

    const quote = line.match(/^\s*>\s?(.*)$/);
    if (quote) {
      flushParagraph();
      flushList();
      output.push(`<blockquote><p>${inlineMarkdown(quote[1])}</p></blockquote>`);
      continue;
    }

    if (!line.trim()) {
      flushParagraph();
      flushList();
      continue;
    }
    flushList();
    paragraph.push(line.trim());
  }

  if (insideCode) flushCode();
  flushParagraph();
  flushList();
  return output.join("\n");
}

function unpackResponse(value, depth = 0) {
  if (depth > 12) return stringifyResponse(value);
  if (typeof value === "string") {
    const text = value.trim();
    if (!text) return "";

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      return text;
    }
    return unpackResponse(parsed, depth + 1);
  }
  if (Array.isArray(value)) {
    return value
      .map((item) => unpackResponse(item, depth + 1))
      .filter(Boolean)
      .join("\n\n");
  }
  if (value && typeof value === "object") {
    const keys = Object.keys(value);
    if ((value.success === false || value.ok === false) && value.error) {
      throw new Error(unpackResponse(value.error, depth + 1));
    }
    if (Object.prototype.hasOwnProperty.call(value, "error") && keys.length <= 2) {
      throw new Error(unpackResponse(value.error, depth + 1));
    }
    const preferredKeys = [
      "analysis",
      "review",
      "result",
      "output",
      "response",
      "recommendations",
      "message",
      "text",
      "content",
      "answer",
      "data",
      "body",
    ];
    for (const key of preferredKeys) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const content = unpackResponse(value[key], depth + 1);
        if (content) return content;
      }
    }
    return stringifyResponse(value);
  }
  return stringifyResponse(value);
}

async function readResponseBody(response) {
  const body = await response.text();
  if (!body.trim()) return "";

  let parsedBody;
  try {
    parsedBody = JSON.parse(body);
  } catch {
    return body.trim();
  }
  return unpackResponse(parsedBody);
}

function startProgressTicker(key) {
  let messageIndex = 0;
  let progress = 12;
  loadingKey.textContent = key;
  loadingStatus.textContent = progressMessages[messageIndex];
  loadingStep.textContent = "STEP 1 OF 4";
  progressFill.style.width = `${progress}%`;

  progressTimer = window.setInterval(() => {
    messageIndex = (messageIndex + 1) % progressMessages.length;
    progress = Math.min(progress + 18, 88);
    loadingStatus.textContent = progressMessages[messageIndex];
    loadingStep.textContent = `STEP ${messageIndex + 1} OF 4`;
    progressFill.style.width = `${progress}%`;
  }, 1500);
}

async function reviewStory(key, modules) {
  workspaceResultContent.replaceChildren();
  setWorkspaceState("loading");
  setFormBusy(true);
  startProgressTicker(key);
  const controller = new AbortController();
  const requestTimeout = window.setTimeout(() => controller.abort(), 45000);

  try {
    const response = await fetch(reviewEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json, text/plain, */*" },
      body: JSON.stringify({ storyKey: key, modules }),
      signal: controller.signal,
    });
    let responseBody;
    try {
      responseBody = await readResponseBody(response);
    } catch (error) {
      if (!response.ok) {
        const detail = error instanceof Error ? error.message : String(error);
        throw new Error(`The review service returned HTTP ${response.status}. ${detail}`);
      }
      throw error;
    }

    if (!response.ok) {
      const detail = responseBody ? ` ${responseBody}` : "";
      throw new Error(`The review service returned HTTP ${response.status}.${detail}`);
    }
    if (!responseBody) {
      throw new Error("The review service returned an empty response. Please try again.");
    }

    workspaceResultContent.innerHTML = renderMarkdown(responseBody);
    resultStoryKey.textContent = key;
    progressFill.style.width = "100%";
    setWorkspaceState("complete");
  } catch (error) {
    const detail = controller.signal.aborted
      ? "The request timed out after 45 seconds."
      : error instanceof Error
        ? error.message
        : String(error);
    showRequestError(`The request to ${reviewEndpoint} failed. ${detail}`);
  } finally {
    window.clearTimeout(requestTimeout);
    clearLoadingTimers();
    setFormBusy(false);
  }
}

analyzerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (requestInProgress) return;

  setWorkspaceState("waiting");
  jiraKeyInput.classList.remove("is-invalid");
  jiraKeyInput.removeAttribute("aria-invalid");

  const key = jiraKeyInput.value.trim().toUpperCase();
  if (!key) {
    jiraKeyInput.classList.add("is-invalid");
    jiraKeyField.classList.add("is-invalid");
    jiraKeyInput.setAttribute("aria-invalid", "true");
    showWorkspaceFeedback("Enter a Jira story key, such as TES-1, before starting your review.");
    jiraKeyInput.focus();
    return;
  }
  if (!jiraKeyInput.checkValidity()) {
    jiraKeyInput.classList.add("is-invalid");
    jiraKeyField.classList.add("is-invalid");
    jiraKeyInput.setAttribute("aria-invalid", "true");
    showWorkspaceFeedback("That Jira key doesn’t look valid. Use a key such as TES-1.");
    jiraKeyInput.focus();
    return;
  }

  const modules = analyzerModules
    .filter((module) => module.checked)
    .map((module) => module.value);
  if (modules.length === 0) {
    showWorkspaceFeedback("Select at least one review module to continue.");
    return;
  }

  await reviewStory(key, modules);
});

jiraKeyInput.addEventListener("input", () => {
  jiraKeyInput.classList.remove("is-invalid");
  jiraKeyField.classList.remove("is-invalid");
  jiraKeyInput.removeAttribute("aria-invalid");
  workspaceFeedback.hidden = true;
  if (workspace.dataset.state === "error" || workspace.dataset.state === "complete") {
    setWorkspaceState("waiting");
  }
});

for (const module of analyzerModules) {
  module.addEventListener("change", () => {
    workspaceFeedback.hidden = true;
  });
}

document.querySelector("#workspace-retry").addEventListener("click", () => {
  analyzerForm.requestSubmit();
});

document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    searchInput.focus();
  }
});
